points(x[11],y[11],col="orange",pch=3,lwd=3,cex=3)
segments(x[8],y[8],x[11],y[11],lwd=3,col="orange")
