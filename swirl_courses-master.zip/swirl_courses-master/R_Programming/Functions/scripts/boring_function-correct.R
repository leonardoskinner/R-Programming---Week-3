boring_function <- function(x) {
  x
}
